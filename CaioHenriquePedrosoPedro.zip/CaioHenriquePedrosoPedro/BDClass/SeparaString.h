/*
APS DE PROG
ALUNO: CAIO HENRIQUE PEDROSO PEDRO
RA:1602950
ENGENHARIA ELETRÔNICA
PROF: LUCIO VALENTIN 
*/
#ifndef BDSplitter_H
#define BDSplitter_H

#include <iostream>
#include <fstream>
#include <string>
#include <string.h>

using namespace std;


class SeparaString{

public:
	void splitter(string linha, string linhasplitada[]);
};


#endif